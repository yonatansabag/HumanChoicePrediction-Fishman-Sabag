# cloning your code from github:
git clone https://github.com/eilamshapira/NLP_project.git

# Your main sweep:
python final_sweep_YOUR_UID.py

# More runs appear in your report:
# python sweep_1.py
# python sweep_2.py
# python sweep_3.py
